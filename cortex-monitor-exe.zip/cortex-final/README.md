# Cortex Monitor v2.0

Painel profissional de monitoramento do sistema em tempo real.

---

## 🚀 OPÇÃO 1 — Gerar um .EXE (recomendado para distribuir / apresentar)

Isso cria um arquivo `.exe` que roda em **qualquer Windows, sem precisar instalar Node.js nem VS Code**.

**Você (quem está gerando o .exe) precisa ter Node.js instalado uma única vez.**
Quem for **usar** o .exe depois não precisa instalar nada.

### Passos:

1. Extraia esse projeto numa pasta
2. Dê **dois cliques em `gerar_exe.bat`**
3. Aguarde o processo terminar (pode levar 2-5 minutos na primeira vez)
4. Quando terminar, abra a pasta **`dist`** — ela vai conter:
   - `CortexMonitor.exe`
   - pasta `public/`
5. **Compartilhe a pasta `dist` inteira** (zipe e envie, copie pro pendrive, etc.)

### Para quem for usar o .exe:

1. Extraia a pasta `dist`
2. Dê dois cliques em `CortexMonitor.exe`
3. O navegador abre sozinho em `http://localhost:3000`
4. Pronto — **não precisa instalar nada**

> ⚠️ Importante: o arquivo `.exe` e a pasta `public` **precisam estar sempre juntos**, na mesma pasta.

---

## 🛠 OPÇÃO 2 — Rodar via VS Code / Node.js (para desenvolvimento)

1. Abra a pasta no VS Code
2. `Ctrl + J` → terminal
3. `npm install`
4. `npm start`
5. Acesse `http://localhost:3000`

Ou dê dois cliques em `iniciar.bat`.

---

## Funcionalidades

- **CPU** — carga total, por núcleo, temperatura, modelo
- **RAM** — uso, swap, donut chart de distribuição
- **Disco** — todas as partições com barra de uso
- **Rede** — RX/TX por interface em Mbps
- **Processos** — top 10 por CPU com gráfico inline
- **Bateria** — para notebooks (detecta automaticamente)
- Atualização a cada 3 segundos
- Interface dark premium, responsiva
- Abre o navegador automaticamente ao iniciar

---

**Requisitos para gerar o .exe:** Node.js 16+ (só na máquina que gera)
**Requisitos para usar o .exe pronto:** nenhum — roda em qualquer Windows 10/11
