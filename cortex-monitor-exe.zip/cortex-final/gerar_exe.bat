@echo off
chcp 65001 >nul
title Cortex Monitor - Gerador de EXE

echo.
echo  ===================================================
echo   CORTEX MONITOR - Gerador de Executavel (.exe)
echo  ===================================================
echo.

where node >nul 2>nul
if %errorlevel% neq 0 (
  echo  [ERRO] Node.js nao encontrado!
  echo  Baixe e instale em: https://nodejs.org/
  echo.
  pause
  exit /b 1
)

echo  [1/3] Instalando dependencias do projeto...
call npm install
echo.

echo  [2/3] Instalando ferramenta de empacotamento (pkg)...
call npm install --save-dev pkg
echo.

echo  [3/3] Gerando o executavel CortexMonitor.exe...
echo  Isso pode levar alguns minutos na primeira vez...
echo.
call npx pkg . --targets node18-win-x64 --output dist\CortexMonitor.exe

echo.
if exist "dist\CortexMonitor.exe" (
  echo  ===================================================
  echo   SUCESSO! Executavel gerado em: dist\CortexMonitor.exe
  echo  ===================================================
  echo.
  echo  IMPORTANTE: copie a pasta "public" para dentro de "dist"
  echo  antes de distribuir o .exe para outras pessoas.
  echo.
  echo  Copiando automaticamente...
  xcopy /E /I /Y public dist\public >nul
  echo  Pronto! A pasta dist\ contem tudo que voce precisa:
  echo    - dist\CortexMonitor.exe
  echo    - dist\public\
  echo.
  echo  Basta compartilhar a pasta "dist" inteira.
) else (
  echo  [ERRO] Falha ao gerar o executavel. Verifique as mensagens acima.
)

echo.
pause
