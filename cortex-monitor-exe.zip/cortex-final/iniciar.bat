@echo off
chcp 65001 >nul
title Cortex Monitor

echo.
echo  ██████╗ ██████╗ ██████╗ ████████╗███████╗██╗  ██╗
echo ██╔════╝██╔═══██╗██╔══██╗╚══██╔══╝██╔════╝╚██╗██╔╝
echo ██║     ██║   ██║██████╔╝   ██║   █████╗   ╚███╔╝
echo ██║     ██║   ██║██╔══██╗   ██║   ██╔══╝   ██╔██╗
echo ╚██████╗╚██████╔╝██║  ██║   ██║   ███████╗██╔╝ ██╗
echo  ╚═════╝ ╚═════╝ ╚═╝  ╚═╝   ╚═╝   ╚══════╝╚═╝  ╚═╝
echo.

where node >nul 2>nul
if %errorlevel% neq 0 (
  echo  [ERRO] Node.js nao encontrado!
  echo  Baixe em: https://nodejs.org/
  echo.
  pause
  exit /b 1
)

if not exist "node_modules\" (
  echo  Instalando dependencias pela primeira vez...
  echo.
  npm install
  echo.
)

echo  Acesse: http://localhost:3000
echo  Pressione Ctrl+C para encerrar.
echo.
node server.js
pause
